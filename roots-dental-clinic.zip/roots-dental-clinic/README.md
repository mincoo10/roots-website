# ROOTS Dental Clinic — Website

**Dr Mayank Gupta | BDS, MDS | Implant Prosthodontist**  
27, Lower Ground Floor, Roots Courtyard Society, Sector 48, Gurugram  
📞 +91 93544 56349 | 📧 Rootsdentalclinic48@gmail.com

---

## Project Structure

```
roots-dental-clinic/
├── index.html          ← Main homepage (upload this to GitHub)
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← Nav scroll, animations, booking form
├── images/             ← Add clinic/case photos here
├── vercel.json         ← Vercel deployment config
├── robots.txt          ← SEO — allows all crawlers
├── sitemap.xml         ← SEO — page index for Google
└── README.md           ← This file
```

---

## Deploy to Vercel (5 minutes)

1. Go to **github.com** → New repository → `roots-dental-clinic`
2. Upload ALL files in this folder (keep the folder structure)
3. Go to **vercel.com** → Add New Project → Select the repo
4. Click **Deploy** — no settings needed
5. Live at: `roots-dental-clinic.vercel.app`

## Add Custom Domain

1. Buy `rootsdentalclinic.in` from GoDaddy / Hostinger (~₹800/yr)
2. Vercel → Project → Settings → Domains → Add domain
3. Copy the DNS records Vercel gives you
4. Paste into GoDaddy/Hostinger DNS settings
5. Live in ~10 minutes ✅

## To Update the Website

1. Edit `index.html`, `css/style.css`, or `js/main.js`
2. Upload the changed file to GitHub
3. Vercel auto-deploys in ~30 seconds ⚡

## Add New Reviews

Open `index.html` → Find `test-card` sections → Edit the quote text and patient name.

## Contact Info to Update

All contact details are in `index.html`:
- Phone: +91 93544 56349
- WhatsApp: https://wa.link/iko83w
- Email: Rootsdentalclinic48@gmail.com
- Address: 27 LGF, Roots Courtyard Society, Sector 48, Gurugram
- Maps: https://maps.app.goo.gl/EK4vxAjMksi7mUV97
