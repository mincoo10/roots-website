/* ============================================================
   ROOTS DENTAL CLINIC — Main JavaScript
   ============================================================ */


// Nav scroll
window.addEventListener('scroll', function() {
  var nav = document.getElementById('mainNav');
  if(window.scrollY > 60) nav.classList.add('scrolled');
  else nav.classList.remove('scrolled');
});

// Reveal on scroll
(function() {
  function checkReveal() {
    var elements = document.querySelectorAll('.reveal');
    elements.forEach(function(el) {
      var rect = el.getBoundingClientRect();
      if(rect.top < window.innerHeight * 0.88) {
        el.classList.add('visible');
      }
    });
  }
  window.addEventListener('scroll', checkReveal);
  checkReveal();
})();

// Mobile menu
var mobileMenuOpen = false;
function toggleMobileMenu() {
  if(mobileMenuOpen) {
    document.getElementById('mobileMenu').remove();
    mobileMenuOpen = false;
  } else {
    var menu = document.createElement('div');
    menu.id = 'mobileMenu';
    menu.style.cssText = 'position:fixed;inset:0;background:rgba(10,10,10,0.98);z-index:99;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:32px;';
    var links = [['About','#about'],['Services','#services'],['Transformations','#cases'],['Technology','#technology'],['Stories','#testimonials'],['Book Consultation','#booking']];
    links.forEach(function(l) {
      var a = document.createElement('a');
      a.href = l[1];
      a.textContent = l[0];
      a.style.cssText = 'font-family:var(--serif);font-size:32px;color:white;font-weight:300;letter-spacing:2px;';
      a.addEventListener('click', function() { menu.remove(); mobileMenuOpen=false; });
      menu.appendChild(a);
    });
    var closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = 'position:absolute;top:28px;right:32px;background:none;border:none;color:white;font-size:24px;cursor:pointer;';
    closeBtn.addEventListener('click', function() { menu.remove(); mobileMenuOpen=false; });
    menu.appendChild(closeBtn);
    document.body.appendChild(menu);
    mobileMenuOpen = true;
  }
}

// Booking form
function submitBooking(btn) {
  var name = document.querySelector('#booking input[type="text"]').value;
  var phone = document.querySelector('#booking input[type="tel"]').value;
  if(!name || !phone) { alert('Please enter your name and phone number.'); return; }
  btn.textContent = 'Sending...';
  btn.disabled = true;
  setTimeout(function() {
    var msg = 'Hi Dr Mayank, I would like to book a consultation.%0AName: '+encodeURIComponent(name)+'%0APhone: '+encodeURIComponent(phone);
    window.open('https://wa.link/iko83w', '_blank');
    btn.textContent = '✓ Request Sent — Redirecting to WhatsApp';
    btn.style.background = '#1a472a';
    btn.style.color = '#4ade80';
  }, 600);
}
